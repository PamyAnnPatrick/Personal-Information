﻿using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;

namespace PersonalInformation
{
    public class VM : INotifyPropertyChanged
    {
        public const string DEFAULT_IMAGE = "images/dummy.jpg";
        public const string ROOT_FOLDER = "images";
        public const int LIMIT = 3;
        private string name, phone, address, image = DEFAULT_IMAGE, message;
        private int age, count = 0;
        public PersonalDataCollection Persons = new PersonalDataCollection();
        public string Name { get => name; set { name = value; onChange(); } }
        public string Phone { get => phone; set { phone = value; onChange(); } }
        public int Age { get => age; set { age = value; onChange(); } }
        public int Count { get => count; set { count = value; onChange(); } }
        public string Address { get => address; set { address = value; onChange(); } }
        public string Image { get => image; set { image = value; onChange(); } }
        public string Message { get => message; set { message = value; onChange(); } }
        Preview PreviewWindow;
        public bool CheckDisplay()
        {
            bool res = true;
            Message = "";
            if (count < LIMIT)
            {
                res = false;
                Message = "Please add " + LIMIT + " applicants";
            }
            return res;
        }
        public void AddNew()
        {
            if (count < LIMIT)
            {
                PersonalData person = new PersonalData() { Name = Name, Address = Address, Age = Age, PhoneNumber = Phone, Image = Image };
                Persons.PersonalDataLists.Add(person);
                ClearData();
                count++;
            }
            else
            {
                ClearData();
                Message = "You can upload only " + LIMIT + " applicants";
            }
        }
        public void Preview()
        {
            if (PreviewWindow == null && CheckDisplay())
            {
                PreviewWindow = new Preview(Persons);
                PreviewWindow.Closed += PreviewWindow_Closed;
                PreviewWindow.Show();
            }
        }
        public void Closed()
        {
            if (PreviewWindow != null)
                PreviewWindow.Close();
        }
        private void PreviewWindow_Closed(object sender, EventArgs e)
        {
            PreviewWindow = null;
        }
        public void ClearData()
        {
            Name = "";
            Phone = "";
            Age = 0;
            Address = "";
            Image = DEFAULT_IMAGE;
        }
        public void Reset()
        {
            ClearData();
            Persons.PersonalDataLists.Clear();
            Count = 0;
        }
        public void UploadImage()
        {
            try
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.DefaultExt = ".txt";
                fileDialog.Filter = "All supported graphics|*.jpg;*.jpeg;*.png|" +
              "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|" +
              "Portable Network Graphic (*.png)|*.png";
                if (fileDialog.ShowDialog() == true)
                {
                    string name = System.IO.Path.GetFileName(fileDialog.FileName);
                    string destinationPath = GetDestinationPath(name, ROOT_FOLDER);
                    if (!File.Exists(destinationPath))
                        File.Copy(fileDialog.FileName, destinationPath, false);
                    Image = destinationPath;
                }
            }
            catch (Exception)
            {
                Message = "Error in upload";
            }
        }
        private String GetDestinationPath(string filename, string foldername)
        {
            String path = String.Format((System.IO.Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)) + "\\{0}\\", foldername);
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            string fileNameWithpath = path + filename;
            return fileNameWithpath;
        }
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void onChange([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
