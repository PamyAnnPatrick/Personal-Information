﻿using System;
using System.Windows;

namespace PersonalInformation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            vm.AddNew();
        }
        private void BtnPreview_Click(object sender, RoutedEventArgs e)
        {
            vm.Preview();
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            vm.Closed();
        }
        private void BtnUploadImage_Click(object sender, RoutedEventArgs e)
        {
            vm.UploadImage();
        }
        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            vm.Reset();
        }
    }
}
