﻿using System.ComponentModel;

namespace PersonalInformation
{
    public class PersonalData
    {
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public int Age { get; set; }
    }
    public class PersonalDataCollection
    {
        public BindingList<PersonalData> PersonalDataLists { get; set; } = new BindingList<PersonalData>();
    }
}
