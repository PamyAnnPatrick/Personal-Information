﻿using System.Windows;

namespace PersonalInformation
{
    /// <summary>
    /// Interaction logic for Preview.xaml
    /// </summary>
    public partial class Preview : Window
    {
        public Preview(PersonalDataCollection Persons)
        {
            InitializeComponent();
            DataContext = Persons;
        }
    }
}
